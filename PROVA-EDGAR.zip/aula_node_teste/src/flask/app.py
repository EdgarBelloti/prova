from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL
from flask_mysqldb import cursors

app = Flask(__name__)

# Configurações do MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '123456789'
app.config['MYSQL_DB'] = 'lista_compras'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'  # Nome da classe como string porque tava dando merda

mysql = MySQL(app)


# Rotinha para exibir a lista de compras
@app.route('/')
def index():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM itens")
    lista_de_compras = cursor.fetchall()
    cursor.close()
    return render_template('index.html', lista_de_compras=lista_de_compras)

# Rotinha para adicionar um novo item
@app.route('/adicionar', methods=['POST'])
def adicionar():
    descricao = request.form.get('item')
    if descricao:
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO itens (descricao) VALUES (%s)", [descricao])
        mysql.connection.commit()
        cursor.close()
    return redirect(url_for('index'))

# Rotinha para remover um item
@app.route('/remover/<int:id_item>', methods=['POST'])
def remover(id_item):
    cursor = mysql.connection.cursor()
    cursor.execute("DELETE FROM itens WHERE id = %s", (id_item,))
    mysql.connection.commit()
    cursor.close()
    return redirect(url_for('index'))

@app.route('/editar/<int:id_item>')
def editar(id_item):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM itens WHERE id = %s", (id_item,))
    item = cursor.fetchone()
    cursor.close()
    return render_template('editar.html', item=item)

@app.route('/atualizar', methods=['POST'])
def atualizar():
    id_item = request.form.get('id')
    descricao = request.form.get('descricao')
    cursor = mysql.connection.cursor()
    cursor.execute("UPDATE itens SET descricao = %s WHERE id = %s", (descricao, id_item))
    mysql.connection.commit()
    cursor.close()
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)

''' CODIGO DO  MYSQL  :
CREATE DATABASE lista_compras;
USE lista_compras;
CREATE TABLE itens (
   id INT AUTO_INCREMENT PRIMARY KEY,
   descricao VARCHAR(255) NOT NULL
);

SELECT *
FROM itens;'''

# TMJ  BIBICIO 